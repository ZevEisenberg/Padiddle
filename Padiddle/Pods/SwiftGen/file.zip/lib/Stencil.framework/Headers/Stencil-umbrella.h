#ifdef __OBJC__
#import <Cocoa/Cocoa.h>
#endif


FOUNDATION_EXPORT double StencilVersionNumber;
FOUNDATION_EXPORT const unsigned char StencilVersionString[];

