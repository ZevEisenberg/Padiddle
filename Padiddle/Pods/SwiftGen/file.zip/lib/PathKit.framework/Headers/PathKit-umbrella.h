#import <Cocoa/Cocoa.h>


FOUNDATION_EXPORT double PathKitVersionNumber;
FOUNDATION_EXPORT const unsigned char PathKitVersionString[];

