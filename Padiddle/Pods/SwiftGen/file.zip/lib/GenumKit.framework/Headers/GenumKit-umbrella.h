#ifdef __OBJC__
#import <Cocoa/Cocoa.h>
#endif


FOUNDATION_EXPORT double GenumKitVersionNumber;
FOUNDATION_EXPORT const unsigned char GenumKitVersionString[];

